<?php


namespace App\Helper;

 class Constants
{

    const searchtypes = ["currencysearch","countrysearch"];

    const currencyheadersformat = "iso_code,iso_numeric_code,common_name,official_name,symbol";

}
